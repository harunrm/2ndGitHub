﻿namespace SuperShopInventoryApp
{
    partial class SuperShopInventoryUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.shopSaveButton = new System.Windows.Forms.Button();
            this.shopAddressTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.shopNameTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sellItemButton = new System.Windows.Forms.Button();
            this.addItemButton = new System.Windows.Forms.Button();
            this.shopdbDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblshopBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tblshopBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shopdbDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblshopBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblshopBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.shopSaveButton);
            this.groupBox1.Controls.Add(this.shopAddressTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.shopNameTextBox);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(479, 160);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Shop Info";
            // 
            // shopSaveButton
            // 
            this.shopSaveButton.Location = new System.Drawing.Point(375, 126);
            this.shopSaveButton.Name = "shopSaveButton";
            this.shopSaveButton.Size = new System.Drawing.Size(75, 28);
            this.shopSaveButton.TabIndex = 2;
            this.shopSaveButton.Text = "Save";
            this.shopSaveButton.UseVisualStyleBackColor = true;
            this.shopSaveButton.Click += new System.EventHandler(this.shopSaveButton_Click);
            // 
            // shopAddressTextBox
            // 
            this.shopAddressTextBox.Location = new System.Drawing.Point(78, 46);
            this.shopAddressTextBox.Multiline = true;
            this.shopAddressTextBox.Name = "shopAddressTextBox";
            this.shopAddressTextBox.Size = new System.Drawing.Size(372, 74);
            this.shopAddressTextBox.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Address:";
            // 
            // shopNameTextBox
            // 
            this.shopNameTextBox.Location = new System.Drawing.Point(78, 17);
            this.shopNameTextBox.Name = "shopNameTextBox";
            this.shopNameTextBox.Size = new System.Drawing.Size(167, 20);
            this.shopNameTextBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(34, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name:";
            // 
            // sellItemButton
            // 
            this.sellItemButton.Location = new System.Drawing.Point(363, 199);
            this.sellItemButton.Name = "sellItemButton";
            this.sellItemButton.Size = new System.Drawing.Size(108, 41);
            this.sellItemButton.TabIndex = 1;
            this.sellItemButton.Text = "Sell Item";
            this.sellItemButton.UseVisualStyleBackColor = true;
            this.sellItemButton.Click += new System.EventHandler(this.sellItemButton_Click);
            // 
            // addItemButton
            // 
            this.addItemButton.Location = new System.Drawing.Point(39, 199);
            this.addItemButton.Name = "addItemButton";
            this.addItemButton.Size = new System.Drawing.Size(111, 41);
            this.addItemButton.TabIndex = 0;
            this.addItemButton.Text = "Add Item";
            this.addItemButton.UseVisualStyleBackColor = true;
            this.addItemButton.Click += new System.EventHandler(this.addItemButton_Click);
            // 
            // tblshopBindingSource
            // 
            this.tblshopBindingSource.DataMember = "tbl_shop";
            this.tblshopBindingSource.DataSource = this.shopdbDataSetBindingSource;
            // 
            // tblshopBindingSource1
            // 
            this.tblshopBindingSource1.DataMember = "tbl_shop";
            this.tblshopBindingSource1.DataSource = this.shopdbDataSetBindingSource;
            // 
            // SuperShopInventoryUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(562, 415);
            this.Controls.Add(this.addItemButton);
            this.Controls.Add(this.sellItemButton);
            this.Controls.Add(this.groupBox1);
            this.Name = "SuperShopInventoryUI";
            this.Text = "Super Shop Inventory";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button shopSaveButton;
        private System.Windows.Forms.TextBox shopAddressTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox shopNameTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button sellItemButton;
        private System.Windows.Forms.Button addItemButton;
        private System.Windows.Forms.BindingSource shopdbDataSetBindingSource;
        private System.Windows.Forms.BindingSource tblshopBindingSource;
        private System.Windows.Forms.BindingSource tblshopBindingSource1;
    }
}

