﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperShopInventoryApp
{
    public class Shop
    {
        public string Name { get; private set; }
        public string Address { get; private set; }
        private string connectionString;

        public List<Product> Products
        {
            get
            {
                ShopDataBase sdb = new ShopDataBase(connectionString);
                DataTable dt =sdb.GetStockTableData("tbl_stock");
                List<Product> pl = new List<Product>();

                foreach (DataRow row in dt.Rows)
                {
                    string id = row[1] as string;
                    int qty = Convert.ToInt32((row[2]));
                    Product aProduct = new Product(id, qty);
                    pl.Add(aProduct);
                }

                return pl;
            }
        }

        public Shop()
        {
            Name = "";
            Address = "";
        }

        public Shop(string connectionString, string name, string address) : this()
        {
            this.connectionString = connectionString;
            Name = name;
            Address = address;

            ShopDataBase sdb=new ShopDataBase(connectionString);
            sdb.InsertNewShop("tbl_shop",name,address);
        }

        public string AddProduct(Product aProduct)
        {
            ShopDataBase sdb = new ShopDataBase(connectionString);
            if (sdb.IsItemExist("tbl_stock",aProduct.ID))
            {
                int oldQuantity = sdb.GetItemQuantity("tbl_stock", aProduct.ID);
                sdb.UpdateItemQty("tbl_stock", aProduct.ID, aProduct.Quantity + oldQuantity);
                return "Quantity updated";
            }
            sdb.InsertNewItem("tbl_stock", aProduct.ID, aProduct.Quantity);
            return "New product added";
        }

        public string SellProduct(Product aProduct)
        {
            ShopDataBase sdb = new ShopDataBase(connectionString);
            if (sdb.IsItemExist("tbl_stock", aProduct.ID))
            {
                int oldQuantity = sdb.GetItemQuantity("tbl_stock", aProduct.ID);
                if (oldQuantity >= aProduct.Quantity)
                {
                    sdb.UpdateItemQty("tbl_stock", aProduct.ID, oldQuantity - aProduct.Quantity);
                    return "";
                }
                return "Insuficient quantity";
            }
            return "Invalid product id";
        }
    }
}
