﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperShopInventoryApp
{
    public class ShopDataBase
    {
        public string ConnectionString { set; get; }

        public ShopDataBase(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public bool InsertNewShop(string table, string name, string address)
        {
            //INSERT INTO table (Column1, Column2) Values ('string', 1);
            string sql = string.Format("INSERT INTO {0} (name, address) VALUES ('{1}','{2}');", table, name, address);
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand myCommand = new SqlCommand(sql, con);

            try
            {
                con.Open();
                myCommand.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public bool InsertNewItem(string table, string item_id, int item_qty)
        {
            //INSERT INTO table (Column1, Column2) Values ('string', 1);
            string sql = string.Format("INSERT INTO {0} (item_id, item_qty) VALUES ('{1}','{2}');", table, item_id,
                item_qty);
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand myCommand = new SqlCommand(sql, con);

            try
            {
                con.Open();
                myCommand.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public bool UpdateItemQty(string table, string item_id, int item_qty)
        {
            string sql = string.Format("UPDATE {0} SET item_qty='{1}' WHERE item_id='{2}';", table, item_qty, item_id);
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand myCommand = new SqlCommand(sql, con);

            try
            {
                con.Open();
                myCommand.ExecuteNonQuery();
                con.Close();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public bool IsItemExist(string table, string item_id)
        {
            string sql = string.Format("SELECT item_id FROM {0} WHERE item_id='{1}';", table, item_id);
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand myCommand = new SqlCommand(sql, con);

            try
            {
                con.Open();
                SqlDataReader myReader = myCommand.ExecuteReader();
                if (myReader.Read())
                {
                    con.Close();
                    return true;
                }
                con.Close();
                return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public int GetItemQuantity(string table, string item_id)
        {
            string sql = string.Format("SELEcT item_qty FROM {0} WHERE item_id='{1}';", table, item_id);
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand myCommand = new SqlCommand(sql, con);

            try
            {
                con.Open();
                SqlDataReader myReader = myCommand.ExecuteReader();

                int noOfItem = 0;
                if (myReader.Read())
                {
                    noOfItem = Convert.ToInt32(myReader["item_qty"].ToString());
                }
                con.Close();
                return noOfItem;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return 0;
            }
        }


        // your data table
        

        public DataTable GetStockTableData(string table)
        {

            string sql = string.Format("SELEcT * FROM {0}", table);
            SqlConnection con = new SqlConnection(ConnectionString);
            SqlCommand myCommand = new SqlCommand(sql, con);


            // create data adapter
            SqlDataAdapter da = new SqlDataAdapter(myCommand);
            // this will query your database and return the result to your datatable
            DataTable dataTable = new DataTable();
            da.Fill(dataTable);
            con.Close();
            da.Dispose();
            return dataTable;
        }
    }
}
