﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace SuperShopInventoryApp
{
    public partial class SuperShopInventoryUI : Form
    {
        private Shop aShop;
        public string connectionString;

        public SuperShopInventoryUI()
        {
            InitializeComponent();

            connectionString = @"server=localhost\SQLEXPRESS; Integrated Security=True; Connect Timeout=15;Encrypt=False; TrustServerCertificate=False; Database=shop_db;";
        }

        private void shopSaveButton_Click(object sender, EventArgs e)
        {
            aShop = new Shop(connectionString, shopNameTextBox.Text, shopAddressTextBox.Text);

            MessageBox.Show("shop created");
        }

        private void addItemButton_Click(object sender, EventArgs e)
        {
            AddUI addUI = new AddUI(aShop);
            addUI.Show();
        }

        private void sellItemButton_Click(object sender, EventArgs e)
        {
            SellUI sellUI = new SellUI(aShop);
            sellUI.Show();
        }
    }
}
