﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperShopInventoryApp
{
    public class Product
    {
        public string ID { get; private set; }
        public int Quantity { get; private set; }

        public Product()
        {
            ID = "";
            Quantity = 0;
        }

        public Product(string id, int qty) : this ()
        {
            ID = id;
            Quantity = qty;
        }

        public void AddQuantity(int quantity)
        {
            Quantity += quantity;
        }

        public bool DeductQuantity(int quantity)
        {
            if (Quantity < quantity)
            {
                return false;
            }
            Quantity -= quantity;
            return true;
        }
    }
}
