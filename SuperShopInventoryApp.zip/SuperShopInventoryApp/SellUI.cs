﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperShopInventoryApp
{
    public partial class SellUI : Form
    {
        private Shop shop;

        public SellUI()
        {
            InitializeComponent();
        }

        public SellUI(Shop aShop)
            : this()
        {
            shop = aShop;
        }

        private void SellUI_Load(object sender, EventArgs e)
        {
            ShowProductsOnListView();
        }

        private void productSellButton_Click(object sender, EventArgs e)
        {
            
            int qty = Convert.ToInt16(productQtyTextBox.Text);
            Product aProduct = new Product(productIdTextBox.Text, qty);

            string msg = shop.SellProduct(aProduct);

            ShowProductsOnListView();

            if (msg != "")
                MessageBox.Show(msg);
        }
        void ShowProductsOnListView()
        {
            productsListView.Items.Clear();
            foreach (Product aProduct in shop.Products)
            {
                ListViewItem anItem = new ListViewItem();
                anItem.Text = aProduct.ID;
                anItem.SubItems.Add(aProduct.Quantity.ToString());
                productsListView.Items.Add(anItem);
            }
        }
    }
}
