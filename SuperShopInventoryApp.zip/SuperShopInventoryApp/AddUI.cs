﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SuperShopInventoryApp
{
    public partial class AddUI : Form
    {
        private Shop shop;

        public AddUI()
        {
            InitializeComponent();
            shop = new Shop();
        }

        public AddUI(Shop aShop) : this()
        {
            shop = aShop;
        }

        private void AddUI_Load(object sender, EventArgs e)
        {
            ShowProductsOnListView();
        }

        private void productAddButton_Click(object sender, EventArgs e)
        {
            int qty = Convert.ToInt16(productQtyTextBox.Text);
            Product aProduct = new Product(productIdTextBox.Text, qty);

            string msg = shop.AddProduct(aProduct);
            ShowProductsOnListView();

            //MessageBox.Show(msg);
        }

        void ShowProductsOnListView()
        {
            productsListView.Items.Clear();
            foreach (Product aProduct in shop.Products)
            {
                ListViewItem anItem = new ListViewItem();
                anItem.Text = aProduct.ID;
                anItem.SubItems.Add(aProduct.Quantity.ToString());
                productsListView.Items.Add(anItem);
            }
        }
    }
}
