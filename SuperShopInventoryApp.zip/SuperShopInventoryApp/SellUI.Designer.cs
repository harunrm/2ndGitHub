﻿namespace SuperShopInventoryApp
{
    partial class SellUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.productSellButton = new System.Windows.Forms.Button();
            this.productQtyTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.productIdTextBox = new System.Windows.Forms.TextBox();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.productsListView = new System.Windows.Forms.ListView();
            this.SuspendLayout();
            // 
            // productSellButton
            // 
            this.productSellButton.Location = new System.Drawing.Point(73, 65);
            this.productSellButton.Name = "productSellButton";
            this.productSellButton.Size = new System.Drawing.Size(107, 23);
            this.productSellButton.TabIndex = 2;
            this.productSellButton.Text = "Sell";
            this.productSellButton.UseVisualStyleBackColor = true;
            this.productSellButton.Click += new System.EventHandler(this.productSellButton_Click);
            // 
            // productQtyTextBox
            // 
            this.productQtyTextBox.Location = new System.Drawing.Point(73, 39);
            this.productQtyTextBox.Name = "productQtyTextBox";
            this.productQtyTextBox.Size = new System.Drawing.Size(107, 20);
            this.productQtyTextBox.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 9;
            this.label3.Text = "Product ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 42);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "Quantity:";
            // 
            // productIdTextBox
            // 
            this.productIdTextBox.Location = new System.Drawing.Point(73, 13);
            this.productIdTextBox.Name = "productIdTextBox";
            this.productIdTextBox.Size = new System.Drawing.Size(107, 20);
            this.productIdTextBox.TabIndex = 0;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "ID";
            this.columnHeader1.Width = 196;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Qty";
            this.columnHeader2.Width = 190;
            // 
            // productsListView
            // 
            this.productsListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.productsListView.Location = new System.Drawing.Point(12, 94);
            this.productsListView.Name = "productsListView";
            this.productsListView.Size = new System.Drawing.Size(415, 216);
            this.productsListView.TabIndex = 14;
            this.productsListView.UseCompatibleStateImageBehavior = false;
            this.productsListView.View = System.Windows.Forms.View.Details;
            // 
            // SellUI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 326);
            this.Controls.Add(this.productsListView);
            this.Controls.Add(this.productSellButton);
            this.Controls.Add(this.productQtyTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.productIdTextBox);
            this.Name = "SellUI";
            this.Text = "SellUI";
            this.Load += new System.EventHandler(this.SellUI_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button productSellButton;
        private System.Windows.Forms.TextBox productQtyTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox productIdTextBox;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ListView productsListView;
    }
}